<?php

/*
* PayPal API configuration
* Remember to switch to your live API keys in production!
* See your keys here: https://developer.paypal.com/
*/
define('PAYPAL_API_CLIENT_ID', 'AUdPX1cVPMqMAjsQ3k5IYiBTWysw5Q4IJkzyB0oRaFp5w6u-_CsYhIcJhHLB9lwwvLBKkEEZTIv6vkIh');
define('PAYPAL_API_SECRET', 'EHAQBsV7RnN9Fcz_tu_Sao4dfhScy-nZzluCC-Udgcp-QExpEpg9T4lLYXdZn-zpA1Y7RHL2pzxVN7q1');
define('PAYPAL_SANDBOX', true); //set false for production
