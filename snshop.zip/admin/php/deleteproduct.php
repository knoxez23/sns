<?php
include_once 'dbconn.php';

if (!empty($_POST['dele-id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['dele-id'];

    $query = "DELETE FROM products where id = ? LIMIT 1";
    $prep_query = $conn->prepare($query);
    $prep_query->bind_param('i', $id);
    $prep_query->execute();
    $prep_query->close();

    header('location: ../products.php?msg=success');
    exit();
}
